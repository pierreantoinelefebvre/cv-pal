import { useState } from "react";
import { useI18n } from "./hooks/useI18n";
import LangSwitch from "./components/LangSwitch";
import MonolithView from "./components/MonolithView";
import MicroservicesView from "./components/MicroservicesView";
import CanvasView from "./components/CanvasView";
import SectionPanel from "./components/SectionPanel";
import ExperienceDrawer from "./components/ExperienceDrawer";
import ContactForm from "./components/ContactForm";

export default function App() {
  const [view, setView] = useState("monolith"); // monolith | microservices | canvas
  const [activeSection, setActiveSection] = useState(null); // about | skills | education | languages
  const [selectedExperience, setSelectedExperience] = useState(null);
  const [showContact, setShowContact] = useState(false);

  const handleDeploy = () => setView("microservices");

  const handleSelectNode = (nodeId) => {
    if (nodeId === "experiences") {
      setView("canvas");
    } else if (nodeId === "contact") {
      setShowContact(true);
    } else {
      setActiveSection(nodeId);
    }
  };

  const handleBackToMenu = () => {
    setView("microservices");
    setSelectedExperience(null);
  };

  return (
    <>
      <div className="grid-bg" />
      <LangSwitch />

      {view === "monolith" && <MonolithView onDeploy={handleDeploy} />}

      {view === "microservices" && (
        <>
          <MicroservicesView onSelectNode={handleSelectNode} />
          <button
            onClick={() => setView("monolith")}
            style={{
              position: "fixed",
              top: 20,
              left: 20,
              zIndex: 20,
              background: "var(--bg-card)",
              border: "1px solid var(--border-subtle)",
              color: "var(--text-secondary)",
              padding: "8px 16px",
              borderRadius: 8,
              cursor: "pointer",
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 13,
              transition: "all 0.2s",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            ← Monolithe
          </button>
        </>
      )}

      {view === "canvas" && (
        <CanvasView
          onBack={handleBackToMenu}
          onSelectExperience={(exp) => setSelectedExperience(exp)}
        />
      )}

      {activeSection && (
        <SectionPanel section={activeSection} onClose={() => setActiveSection(null)} />
      )}

      {selectedExperience && (
        <ExperienceDrawer
          experience={selectedExperience}
          onClose={() => setSelectedExperience(null)}
        />
      )}

      {showContact && <ContactForm onClose={() => setShowContact(false)} />}
    </>
  );
}
