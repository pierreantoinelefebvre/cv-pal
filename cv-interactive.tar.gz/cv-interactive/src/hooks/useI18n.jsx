import { createContext, useContext, useState, useCallback } from "react";
import { CV_FR, UI_FR } from "../data/cv-fr";
import { CV_EN, UI_EN } from "../data/cv-en";

const I18nContext = createContext();

export function I18nProvider({ children }) {
  const [lang, setLang] = useState("fr");

  const toggle = useCallback(() => {
    setLang((prev) => (prev === "fr" ? "en" : "fr"));
  }, []);

  const cv = lang === "fr" ? CV_FR : CV_EN;
  const ui = lang === "fr" ? UI_FR : UI_EN;

  return (
    <I18nContext.Provider value={{ lang, toggle, cv, ui }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
