# CV Interactif — Du Monolithe aux Microservices

CV en ligne interactif de **Pierre-Antoine Lefebvre** — Architecte SI & Manager.

La métaphore visuelle : transformer un monolithe en microservices, avec un parcours d'expériences façon workflow n8n.

## Stack Technique

- **React 18** + **Vite**
- **Tailwind CSS** pour le styling
- **CSS Animations** (Bézier curves, particles, morphing)
- **Docker** + **Nginx** pour le déploiement prod
- **i18n** FR / EN intégré

## Démarrage rapide

### Développement local

```bash
npm install
npm run dev
```

→ Accessible sur `http://localhost:5173`

### Build production

```bash
npm run build
npm run preview
```

### Docker (production)

```bash
# Build et lancer
docker compose up -d --build

# Ou manuellement
docker build -t cv-interactive .
docker run -d -p 80:80 --name cv-pa-lefebvre cv-interactive
```

→ Accessible sur `http://localhost`

## Configuration

### Formulaire de contact

Le formulaire de contact utilise [Formspree](https://formspree.io) (gratuit).

1. Créer un formulaire sur Formspree
2. Créer un fichier `.env` à la racine :

```env
VITE_FORMSPREE_URL=https://formspree.io/f/VOTRE_ID
```

Sans Formspree configuré, le formulaire ouvre un `mailto:` en fallback.

## Structure du projet

```
cv-interactive/
├── src/
│   ├── components/       # Composants React
│   │   ├── MonolithView.jsx      # Vue 1 - Landing
│   │   ├── MicroservicesView.jsx # Vue 2 - Menu éclaté
│   │   ├── CanvasView.jsx        # Vue 3 - Workflow n8n
│   │   ├── ExperienceDrawer.jsx  # Vue 4 - Détail payload
│   │   ├── SectionPanel.jsx      # Modales (About, Skills, etc.)
│   │   ├── ContactForm.jsx       # Formulaire de contact
│   │   └── LangSwitch.jsx        # Switch FR/EN
│   ├── data/
│   │   ├── cv-fr.js              # Données CV français
│   │   ├── cv-en.js              # Données CV anglais
│   │   └── constants.js          # Types de nœuds
│   ├── hooks/
│   │   ├── useI18n.jsx           # Context i18n
│   │   └── useWindowSize.js      # Hook responsive
│   ├── styles/
│   │   └── globals.css           # Styles globaux + animations
│   ├── App.jsx                   # Orchestrateur principal
│   └── main.jsx                  # Point d'entrée
├── Dockerfile                    # Build multi-stage
├── docker-compose.yml
├── nginx.conf                    # Config Nginx SPA
├── package.json
├── vite.config.js
├── tailwind.config.js
└── postcss.config.js
```

## Modifier le contenu

Les données du CV sont dans `src/data/cv-fr.js` et `src/data/cv-en.js`.
La structure `experienceGroups` permet de regrouper les missions consultant :

```js
experienceGroups: [
  {
    id: "group_codeploy",
    isGroup: true,
    label: "Missions Consultant — Codeploy Sàrl",
    children: [ /* ... expériences ... */ ],
  },
  // Expériences hors groupe directement
  { id: "node_pierrefabre", type: "loop", ... },
]
```

## Responsive

- **Desktop** (≥1024px) : Layout complet, canvas scrollable
- **Tablette** (640–1024px) : Nœuds légèrement réduits
- **Mobile** (<640px) : Layout adapté, nœuds en colonne sur le canvas

## Licence

Usage personnel — Pierre-Antoine Lefebvre
